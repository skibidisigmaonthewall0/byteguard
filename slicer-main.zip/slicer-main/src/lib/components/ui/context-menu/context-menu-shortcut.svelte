<script lang="ts">
    import { cn, type WithElementRef } from "$lib/components/utils.js";
    import type { HTMLAttributes } from "svelte/elements";

    let {
        ref = $bindable(null),
        class: className,
        children,
        ...restProps
    }: WithElementRef<HTMLAttributes<HTMLSpanElement>> = $props();
</script>

<span
    bind:this={ref}
    data-slot="context-menu-shortcut"
    class={cn("text-muted-foreground ms-auto text-xs tracking-widest", className)}
    {...restProps}
>
    {@render children?.()}
</span>
